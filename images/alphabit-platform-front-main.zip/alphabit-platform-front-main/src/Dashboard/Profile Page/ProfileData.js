module.exports = [{
    info: 'First Name',
    id: '1'
}, {
    info: 'Last Name',
    id: '2'
}, {
    info: 'phone Number',
    id: '3'
}]